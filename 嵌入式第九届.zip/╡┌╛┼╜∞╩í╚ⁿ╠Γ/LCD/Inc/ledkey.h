#ifndef __LEDKEY_H
#define __LEDKEY_H
#define led1 GPIO_Pin_8
#define key1 GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0)
#define key2 GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_8)
#define key3 GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_1)
#define key4 GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_2)
#include "stm32f10x.h"
void LED_Init(void);
void KEY_Init(void);
void LED_Caozuo(unsigned int led ,unsigned char sta);
unsigned int  KEY_Can(void);
void PWM_Init(u8 pcs,u16 fre,u8 duy);
void RTC_Init(u8 hh,u8 mm,u8 ss);
#endif


