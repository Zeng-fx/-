#include "stm32f10x.h"
#include "stdio.h"
#include "lcd.h"
#include "ledkey.h"
#include "i2c.h"
u32 TimingDelay = 0;
u32 LEDelay = 0;
u32 key2_Time=0;
u32 key3_Time=0;
u32 key4_Time=0;
void LED_H(void);
unsigned char key_val;
void Delay_Ms(u32 nTime);
void RTC_Time(void);
void CaoZuo(void);
unsigned char str[20];
u8 ting=0;//��ʱ��Ϊ1ʱֹͣ
u8 RTC_Flag;
u32 time;
u8 key2_an=0;
u8 key3_an=0;
u8 key4_an=0;
u8 chun=1;
u8 hh=0,mm=0,ss=0;

//Main Body
int main(void)
{
	SysTick_Config(SystemCoreClock/1000);
	LED_Init();
	KEY_Init();
	PWM_Init(71,1000,80);
	RTC_Init(23,59,55);
	Delay_Ms(200);
	
	STM3210B_LCD_Init();
	LCD_Clear(Blue);
	LCD_SetBackColor(Blue);
	LCD_SetTextColor(White);



	while(1)
	{
		xie(0x03,1);
		xie(0x04,10);
		xie(0x05,100);
		xie(0x06,100);
		xie(0x07,255);
		key_val=KEY_Can();
		LED_H();
		RTC_Time();
		CaoZuo();

	}	
	;
}

//
void Delay_Ms(u32 nTime)
{
	TimingDelay = nTime;
	while(TimingDelay != 0);	
}
void RTC_Time(void)
{
	if(RTC_Flag)
	{
		RTC_Flag=0;
		time=RTC_GetCounter();
		RTC_WaitForLastTask();
		if(time==(23*3600+59*60+59))
		{
			RTC_SetCounter(0);
			RTC_WaitForLastTask();
		}else
		{
			hh=time/3600;
			mm=time%3600/60;
			ss=time%3600%60;
		}
	}
}
void LED_H(void)
{
	if(ting==0)
	{
	if(LEDelay<=500)
	{
		LED_Caozuo(led1,0);
	}else if(LEDelay<=1000)
	{
		LED_Caozuo(led1,1);
	}else if(LEDelay>1000)LEDelay=0;
	}
	else if(ting==1)
	{
		LEDelay=0;
		LED_Caozuo(led1,1);
	}
}
//�߼�����
void CaoZuo(void)
{
	if(key_val==1)
	{
		Delay_Ms(20);
		if(key_val==1)
		{
				chun++;
				if(chun>=6){
					chun=1;
				}
		}
	}
	if(key_val==2)
	{
		key2_an=1;
			if(key2_Time>=20)
			{
				 
			}
			if(key2_Time>=800)
			{
			}
	}else
	{
		key2_an=0;
		key2_Time=0;
	}
	if(key_val==3)
	{
		key3_an=1;
			if(key3_Time>=20)
			{
				 
			}
			if(key3_Time>=800)
			{
			}
	}else
	{
		key3_an=0;
		key3_Time=0;
	}	
	if(key_val==4)
	{
		key4_an=1;
			if(key4_Time>=20)
			{
				 
			}
			if(key4_Time>=800)
			{
			}
	}else
	{
		key4_an=0;
		key4_Time=0;
	}	
}
void SysTick_Handler(void)
{
	TimingDelay--;
	LEDelay++;
	if(key2_an==1)
	{
		key2_Time++;
	}
	if(key3_an==1)
	{
		key3_Time++;
	}
		if(key4_an==1)
	{
		key4_Time++;
	}
}

